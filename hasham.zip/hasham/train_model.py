# ==========================================
# 🏏 IPL MATCH WINNER PREDICTION MODEL (FIXED)
# ==========================================

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import pickle

# -------------------------------
# 1️⃣ Load Dataset
# -------------------------------
df = pd.read_csv("IPL.csv")
print("✅ Dataset Loaded Successfully!")
print("Shape:", df.shape)
print()

# -------------------------------
# 2️⃣ Check available columns
# -------------------------------
print("📋 Columns available:\n", df.columns.tolist(), "\n")

# -------------------------------
# 3️⃣ Create Winner Column (smart detection)
# -------------------------------
if "winner" in df.columns:
    df["winner_final"] = df["winner"]

elif "superover_winner" in df.columns and df["superover_winner"].notna().any():
    df["winner_final"] = df["superover_winner"]

elif "win_outcome" in df.columns and df["win_outcome"].notna().any():
    df["winner_final"] = df["win_outcome"]

elif "match_won_by" in df.columns:
    # If match_won_by has Batting/Bowling Team text
    def get_winner(row):
        if str(row["match_won_by"]).lower().startswith("batting"):
            return row["batting_team"]
        elif str(row["match_won_by"]).lower().startswith("bowling"):
            return row["bowling_team"]
        else:
            return None
    df["winner_final"] = df.apply(get_winner, axis=1)

else:
    raise ValueError("❌ Could not detect any winner-related column in dataset!")

# Drop rows without a winner
df = df.dropna(subset=["winner_final"])

if df.empty:
    raise ValueError("❌ No winner data found — please verify CSV content!")

print("🏆 Winner column created successfully!")
print(df[["batting_team", "bowling_team", "winner_final"]].head(), "\n")

# -------------------------------
# 4️⃣ Feature Selection
# -------------------------------
features = ["batting_team", "bowling_team", "venue", "toss_winner", "toss_decision"]
target = "winner_final"

df = df[features + [target]].dropna()

# -------------------------------
# 5️⃣ Encode Categorical Columns
# -------------------------------
le = LabelEncoder()
for col in features + [target]:
    df[col] = le.fit_transform(df[col].astype(str))

# -------------------------------
# 6️⃣ Split Data
# -------------------------------
X = df[features]
y = df[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# -------------------------------
# 7️⃣ Train Model
# -------------------------------
model = RandomForestClassifier(n_estimators=200, random_state=42)
model.fit(X_train, y_train)

print("✅ Model training completed successfully!\n")

# -------------------------------
# 8️⃣ Save Model
# -------------------------------
with open("ipl_winner_model.pkl", "wb") as f:
    pickle.dump(model, f)

print("💾 Model saved as ipl_winner_model.pkl")
print(f"🎯 Training Accuracy: {model.score(X_train, y_train):.2f}")
print(f"🎯 Testing Accuracy: {model.score(X_test, y_test):.2f}")
