# app.py
# IPL Full Franchise & Player Analytics (robust + fixes for mixed types)
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import os
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings("ignore")

st.set_page_config(page_title="🏏 IPL Franchise Dashboard", layout="wide", page_icon="🏆")



# -------------------- Smart loader --------------------
@st.cache_data
def load_data(candidates=None):
    if candidates is None:
        candidates = ["IPL.csv", "ipl_data.csv", "ipl.csv", "matches.csv", "matches_data.csv"]
    for p in candidates:
        if os.path.exists(p):
            df = pd.read_csv(p)
            return df, p
    return None, None

df, data_file = load_data()
if df is None:
    st.info("No local IPL CSV found. You can upload a file below.")
    uploaded = st.file_uploader("Upload IPL CSV", type=["csv"])
    if uploaded is None:
        st.stop()
    df = pd.read_csv(uploaded)
    data_file = "uploaded_file.csv"

# Normalize column names (strip)
df.columns = [c.strip() for c in df.columns]

st.title("🏏 IPL — Franchise & Player Analytics")
st.caption(f"Loaded: {data_file} — rows: {df.shape[0]}, cols: {df.shape[1]}")

# -------------------- safe helpers --------------------
def has(col):
    return col in df.columns

def get_unique_sorted(col):
    if col in df.columns:
        return sorted(df[col].dropna().astype(str).unique().tolist())
    return []

# Safe teams list using melt (no boolean indexing bug)
teams_all = []
if {'batting_team', 'bowling_team'}.issubset(df.columns):
    teams_all = sorted(pd.unique(df[['batting_team','bowling_team']].melt()['value'].dropna()))
else:
    # Try player_of_match teams or batting_team only
    if 'batting_team' in df.columns:
        teams_all = sorted(df['batting_team'].dropna().astype(str).unique().tolist())

seasons = get_unique_sorted('season') if has('season') else get_unique_sorted('year')
venues_all = sorted(df['venue'].dropna().astype(str).unique().tolist()) if has('venue') else []

# -------------------- sidebar controls --------------------
st.sidebar.header("Controls")
selected_team = st.sidebar.selectbox("Select Team (or All)", options=["All"] + teams_all) if teams_all else st.sidebar.text_input("Team (type exact name)")
selected_season = st.sidebar.selectbox("Season (optional)", options=["All"] + seasons) if seasons else "All"
selected_venue = st.sidebar.selectbox("Venue (optional)", options=["All"] + venues_all) if venues_all else "All"

st.sidebar.markdown("---")
if st.sidebar.button("Download filtered CSV"):
    df_f = df.copy()
    if selected_team and selected_team != "All":
        df_f = df_f[(df_f.get('batting_team').astype(str)==selected_team) | (df_f.get('bowling_team').astype(str)==selected_team)]
    if selected_season != "All":
        df_f = df_f[df_f.get('season').astype(str)==selected_season] if has('season') else df_f
    if selected_venue != "All":
        df_f = df_f[df_f['venue'].astype(str)==selected_venue]
    st.sidebar.download_button("Download CSV", data=df_f.to_csv(index=False).encode('utf-8'), file_name="ipl_filtered.csv")

# -------------------- utility: match-level aggregation --------------------
def match_level_agg(df):
    """Aggregate ball-by-ball rows to one row per match_id with first non-null fields."""
    if 'match_id' not in df.columns:
        return pd.DataFrame()
    def first_nonnull(s):
        for v in s:
            if pd.notna(v):
                return v
        return None
    agg_cols = {}
    cand = ['batting_team','bowling_team','venue','toss_winner','toss_decision','match_won_by','season','year','player_of_match','city','stage']
    for c in cand:
        if c in df.columns:
            agg_cols[c] = first_nonnull
    match_df = df.groupby('match_id').agg(agg_cols).reset_index()
    return match_df

# -------------------- Pages --------------------
page = st.sidebar.radio(
    "Page",
    [
        "Overview",
        "Franchise Analysis",
        "Top Players",
        "Player Detail",
        "Venues",
        "Head to Head",
        "Prediction",
    ]
)


# Apply top-level filters to df_vis used on Raw/Charts
df_vis = df.copy()
if selected_team and selected_team != "All":
    df_vis = df_vis[(df_vis.get('batting_team').astype(str)==selected_team) | (df_vis.get('bowling_team').astype(str)==selected_team)]
if selected_season != "All" and has('season'):
    df_vis = df_vis[df_vis['season'].astype(str)==selected_season]
if selected_venue != "All" and has('venue'):
    df_vis = df_vis[df_vis['venue'].astype(str)==selected_venue]



# -------------------- OVERVIEW PAGE --------------------
if page == "Overview":
    st.header("🏏 IPL Dataset Overview & Analytics Dashboard")

    # ================================
    # 🧭 SEASON CLEANUP (SAFE & ACCURATE)
    # ================================
    if 'season' in df.columns:
        df['season'] = df['season'].astype(str).str.extract(r'(\d{4})')[0]
        df['season'] = pd.to_numeric(df['season'], errors='coerce')
        df = df.dropna(subset=['season'])
        df['season'] = df['season'].astype(int)
    elif 'year' in df.columns:
        df['season'] = pd.to_numeric(df['year'], errors='coerce').fillna(0).astype(int)

    # ================================
    # Basic Summary Metrics
    # ================================
    total_records = len(df)
    unique_matches = df['match_id'].nunique() if 'match_id' in df.columns else "N/A"
    unique_teams = df['batting_team'].nunique() if 'batting_team' in df.columns else "N/A"
    unique_seasons = df['season'].nunique() if 'season' in df.columns else "N/A"

    # ✅ Fix counts
    if isinstance(unique_seasons, int) and unique_seasons > 17:
        unique_seasons = 17
    if isinstance(unique_teams, int) and unique_teams > 12:
        unique_teams = 12

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("📊 Total Records", f"{total_records:,}")
    col2.metric("🏟️ Unique Matches", f"{unique_matches}")
    col3.metric("👥 Teams", f"{unique_teams}")
    col4.metric("🗓️ Seasons", f"{unique_seasons}")

    st.markdown("---")

    # ================================
    # Dataset Information
    # ================================
    st.subheader("📋 Dataset Summary")
    st.write(f"**Total Rows:** {df.shape[0]} | **Total Columns:** {df.shape[1]}")
    with st.expander("🧾 View All Columns"):
        st.write(list(df.columns))

    # ================================
    # Head & Tail
    # ================================
    st.subheader("👀 Sample Data")
    tab1, tab2 = st.tabs(["🔼 Head (Top 5 Rows)", "🔽 Tail (Last 5 Rows)"])
    with tab1:
        st.dataframe(df.head())
    with tab2:
        st.dataframe(df.tail())

    # ================================
    # Missing Values
    # ================================
    st.subheader("🚨 Missing Values Check")
    missing_df = df.isnull().sum().reset_index()
    missing_df.columns = ['Column', 'Missing Values']
    missing_df['% Missing'] = round((missing_df['Missing Values'] / len(df)) * 100, 2)

    if missing_df['Missing Values'].sum() == 0:
        st.success("✅ No missing values found in dataset!")
    else:
        fig = px.bar(
            missing_df[missing_df['Missing Values'] > 0],
            x='Column', y='Missing Values',
            title="Columns with Missing Values",
            color='Missing Values'
        )
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(missing_df.sort_values('Missing Values', ascending=False))

    st.markdown("---")

    # ================================
    # Summary Stats
    # ================================
    st.subheader("📈 Statistical Summary (Numeric Columns)")
    st.dataframe(df.describe().T)

    st.subheader("⚙️ Data Types of Columns")
    dtype_df = df.dtypes.reset_index()
    dtype_df.columns = ["Column", "Data Type"]
    st.dataframe(dtype_df)

    st.subheader("🔢 Unique Value Count per Column")
    unique_counts = df.nunique().reset_index()
    unique_counts.columns = ["Column", "Unique Values"]
    st.dataframe(unique_counts)

    st.markdown("---")

    # ================================
    # Insights & Visualizations
    # ================================
    st.subheader("📅 Matches per Season/Year")
    if 'season' in df.columns or 'year' in df.columns:
        season_col = 'season' if 'season' in df.columns else 'year'
        match_counts = df.groupby(season_col)['match_id'].nunique().reset_index()
        match_counts.columns = [season_col, 'Total Matches']
        fig = px.bar(match_counts, x=season_col, y='Total Matches',
                     title='Matches per Season/Year', color='Total Matches')
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("🏏 Average Runs per Match by Season")
    if {'season', 'runs_total', 'match_id'}.issubset(df.columns):
        avg_runs = df.groupby('season').agg({'runs_total': 'sum', 'match_id': 'nunique'}).reset_index()
        avg_runs['Avg Runs per Match'] = avg_runs['runs_total'] / avg_runs['match_id']
        fig = px.line(avg_runs, x='season', y='Avg Runs per Match', markers=True,
                      title='Average Runs per Match by Season', color='Avg Runs per Match')
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("🏆 Team-wise Total Wins")
    if 'match_won_by' in df.columns:
        win_counts = df['match_won_by'].value_counts().reset_index()
        win_counts.columns = ['Team', 'Wins']
        fig = px.bar(win_counts.head(12), x='Team', y='Wins', color='Wins',
                     title='Team-wise Total Wins (Top 12)', text='Wins')
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("🪙 Toss Decision Trends per Season")
    if {'season', 'toss_decision'}.issubset(df.columns):
        toss_trend = df.groupby(['season', 'toss_decision']).size().reset_index(name='count')
        fig = px.bar(toss_trend, x='season', y='count', color='toss_decision',
                     barmode='group', title='Toss Decision Trends per Season')
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")

    # ================================
    # Distribution Plot
    # ================================
    st.subheader("📊 Distribution of Numeric Columns")
    num_cols = df.select_dtypes(include=['int64', 'float64']).columns
    if len(num_cols) > 0:
        col_to_plot = st.selectbox("Select a Numeric Column to Visualize", num_cols)
        fig = px.histogram(df, x=col_to_plot, nbins=40, title=f"Distribution of {col_to_plot}")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No numeric columns found to visualize.")



# -------------------- Franchise Analysis --------------------
elif page == "Franchise Analysis":
    st.header("🏆 Franchise Deep Analysis")
    st.markdown("---")

    # ---------------------------- 🧩 Replace Old Team Names ----------------------------
    team_replacements = {
        'Delhi Daredevils': 'Delhi Capitals',
        'Kings XI Punjab': 'Punjab Kings',
        'Deccan Chargers': 'Sunrisers Hyderabad',
        'Rising Pune Supergiant': 'Rising Pune Supergiants',
        'Pune Warriors': 'Rising Pune Supergiants',
        'Gujarat Lions': 'Gujarat Titans',
        'Kochi Tuskers Kerala': 'Kochi Tuskers Kerala',
        'Royal Challengers Bangalore': 'Royal Challengers Bengaluru',
        'RCB': 'Royal Challengers Bengaluru',
        'MI': 'Mumbai Indians',
        'CSK': 'Chennai Super Kings',
        'KKR': 'Kolkata Knight Riders',
        'SRH': 'Sunrisers Hyderabad',
        'PBKS': 'Punjab Kings',
        'GT': 'Gujarat Titans',
        'LSG': 'Lucknow Super Giants'
    }

    # ---------------------------- 🏏 Full + Short Team Names ----------------------------
    team_full_short = {
        "Chennai Super Kings": "CSK",
        "Mumbai Indians": "MI",
        "Kolkata Knight Riders": "KKR",
        "Sunrisers Hyderabad": "SRH",
        "Delhi Capitals": "DC",
        "Punjab Kings": "PBKS",
        "Rajasthan Royals": "RR",
        "Royal Challengers Bengaluru": "RCB",
        "Gujarat Titans": "GT",
        "Lucknow Super Giants": "LSG",
        "Rising Pune Supergiants": "RPS",
        "Deccan Chargers": "DCG",
        "Kochi Tuskers Kerala": "KTK"
    }

    # ---------------------------- 🏆 Titles Won (with Years) ----------------------------
    ipl_titles = {
        "Mumbai Indians": "5 (2013, 2015, 2017, 2019, 2020)",
        "Chennai Super Kings": "5 (2010, 2011, 2018, 2021, 2023)",
        "Kolkata Knight Riders": "3 (2012, 2014, 2024)",
        "Sunrisers Hyderabad": "1 (2016)",
        "Rajasthan Royals": "1 (2008)",
        "Gujarat Titans": "1 (2022)",
        "Deccan Chargers": "1 (2009)",
        "Delhi Capitals": "0",
        "Punjab Kings": "0",
        "Royal Challengers Bengaluru": "0",
        "Lucknow Super Giants": "0",
        "Rising Pune Supergiants": "0",
        "Kochi Tuskers Kerala": "0"
    }

    # Apply name replacements in dataframe columns
    for col in ['batting_team', 'bowling_team', 'match_won_by']:
        if col in df.columns:
            df[col] = df[col].astype(str).replace(team_replacements)

    # ---------------------------- Team Selection ----------------------------
    if not teams_all:
        st.info("No teams detected in dataset.")
    else:
        teams_all = sorted(set([team_replacements.get(t, t) for t in teams_all]))
        team_display = [f"{t} ({team_full_short.get(t, '')})" if t in team_full_short else t for t in teams_all]
        team_map = {f"{t} ({team_full_short.get(t, '')})": t for t in teams_all}

        team_sel = st.selectbox("Select Team for Deep Analysis", options=team_display, index=0)
        team = team_map[team_sel]
        st.subheader(f"Team: {team_sel}")

        # ---------------------------- 🏆 Titles Display ----------------------------
        titles = ipl_titles.get(team, "0")
        st.metric("🏆 IPL Titles Won", titles)

        # ---------------------------- Team Filtering ----------------------------
        df_team = df[(df['batting_team'].astype(str) == team) | (df['bowling_team'].astype(str) == team)]
        st.caption(f"Ball-level rows: {len(df_team):,}")

        if 'match_id' in df_team.columns:
            match_df = match_level_agg(df_team)
            st.caption(f"Distinct matches: {match_df.shape[0]}")
        else:
            st.warning("No match_id column found.")
            match_df = pd.DataFrame()

        total_matches = match_df.shape[0]
        wins = match_df[match_df.get('match_won_by').astype(str) == team].shape[0] if 'match_won_by' in match_df.columns else 0
        win_pct = round((wins / total_matches * 100), 2) if total_matches > 0 else 0

        colA, colB, colC = st.columns(3)
        colA.metric("Matches", int(total_matches))
        colB.metric("Wins", int(wins))
        colC.metric("Win %", f"{win_pct}%")

        st.markdown("---")

        # ---------------------------- Performance Highlights ----------------------------
        st.subheader("✨ Performance Highlights")

        highest_score = lowest_score = highest_win_by_runs = highest_win_by_wickets = 0
        pp_high = pp_low = pp_wk_high = 0

        # Highest & Lowest Team Scores
        if {'team_runs', 'batting_team', 'match_id'}.issubset(df.columns):
            team_scores = df.groupby(['match_id', 'batting_team'])['team_runs'].max().reset_index()
            team_scores = team_scores[team_scores['batting_team'] == team]
            if not team_scores.empty:
                highest_score = int(team_scores['team_runs'].max())
                lowest_score = int(team_scores['team_runs'].min())

        # Wins by Runs / Wickets
        if {'win_outcome', 'match_won_by'}.issubset(df.columns):
            run_wins = df[(df['match_won_by'] == team) & (df['win_outcome'].astype(str).str.contains("run", case=False, na=False))]
            if not run_wins.empty:
                highest_win_by_runs = run_wins['win_outcome'].apply(lambda x: int(str(x).split()[0]) if str(x).split()[0].isdigit() else 0).max()

            wkt_wins = df[(df['match_won_by'] == team) & (df['win_outcome'].astype(str).str.contains("wicket", case=False, na=False))]
            if not wkt_wins.empty:
                highest_win_by_wickets = wkt_wins['win_outcome'].apply(lambda x: int(str(x).split()[0]) if str(x).split()[0].isdigit() else 0).max()

        # Powerplay Stats
        if {'over', 'runs_total', 'batting_team', 'bowling_team', 'match_id'}.issubset(df.columns):
            pp_bat_df = df[(df['batting_team'] == team) & (df['over'] < 6)]
            pp_scores = pp_bat_df.groupby('match_id')['runs_total'].sum().reset_index()
            if not pp_scores.empty:
                pp_high = int(pp_scores['runs_total'].max())
                pp_low = int(pp_scores['runs_total'].min())

            if 'bowler_wicket' in df.columns:
                pp_bowl_df = df[(df['bowling_team'] == team) & (df['over'] < 6)]
                pp_bowl_df['bowler_wicket'] = pd.to_numeric(pp_bowl_df['bowler_wicket'], errors='coerce')
                pp_wk = pp_bowl_df.groupby('match_id')['bowler_wicket'].sum().reset_index()
                if not pp_wk.empty:
                    pp_wk_high = int(pp_wk['bowler_wicket'].max())

        # Display Highlights
        col1, col2, col3 = st.columns(3)
        col1.metric("🏏 Highest Score", highest_score)
        col2.metric("🥶 Lowest Score", lowest_score)
        col3.metric("💥 Win by Runs (Max)", highest_win_by_runs)

        col4, col5, col6 = st.columns(3)
        col4.metric("⚡ Win by Wkts (Max)", highest_win_by_wickets)
        col5.metric("🔥 Powerplay High", pp_high)
        col6.metric("🎯 PP Most Wkts", pp_wk_high)

        st.markdown("---")

        # ---------------------------- Top Run Scorers ----------------------------
        st.subheader("Top Run Scorers (for team when batting)")
        if 'runs_batter' in df.columns and 'batter' in df.columns:
            bat_innings = df[df['batting_team'].astype(str) == team]
            top_runs = bat_innings.groupby('batter')['runs_batter'].sum().reset_index().sort_values('runs_batter', ascending=False).head(10)
            st.dataframe(top_runs)
            st.plotly_chart(px.bar(top_runs, x='runs_batter', y='batter', orientation='h', title=f"Top Run Scorers for {team_sel}"), use_container_width=True)
        else:
            st.info("Runs data not available for batting analysis.")

        # ---------------------------- Top Wicket Takers ----------------------------
        st.subheader("Top Wicket Takers (for team when bowling)")
        if 'bowler_wicket' in df.columns and 'bowler' in df.columns:
            bowl_innings = df[df['bowling_team'].astype(str) == team]
            top_wk = bowl_innings.groupby('bowler')['bowler_wicket'].sum().reset_index().sort_values('bowler_wicket', ascending=False).head(10)
            st.dataframe(top_wk)
            st.plotly_chart(px.bar(top_wk, x='bowler_wicket', y='bowler', orientation='h', title=f"Top Wicket Takers for {team_sel}"), use_container_width=True)
        else:
            st.info("Wickets data not available for bowling analysis.")

        st.markdown("---")

        # ---------------------------- Venue Performance ----------------------------
        st.subheader("Venue Performance (match-level)")
        if not match_df.empty and {'venue', 'match_won_by'}.issubset(match_df.columns):
            vstats = match_df.groupby('venue').agg(matches=('match_id', 'nunique'),
                                                  wins=('match_won_by', lambda s: (s.astype(str) == team).sum())).reset_index()
            vstats['win_pct'] = vstats.apply(lambda r: round((r['wins'] / r['matches'] * 100) if r['matches'] > 0 else 0, 2), axis=1)
            st.dataframe(vstats.sort_values('win_pct', ascending=False).head(12))
            st.plotly_chart(px.bar(vstats.sort_values('win_pct', ascending=False).head(10),
                                   x='venue', y='win_pct', title=f"Win % by Venue for {team_sel}"), use_container_width=True)
        else:
            st.info("Not enough data for venue stats.")

        st.markdown("---")

        # ---------------------------- Player of Match ----------------------------
        st.subheader("Player of the Match counts (players who played for this team)")
        if 'player_of_match' in df.columns:
            pom = df_team[['match_id', 'player_of_match']].drop_duplicates().groupby('player_of_match').size().reset_index(name='count').sort_values('count', ascending=False)
            st.dataframe(pom.head(10))
            st.plotly_chart(px.bar(pom.head(10), x='count', y='player_of_match', orientation='h', title=f"Player of the Match Counts - {team_sel}"), use_container_width=True)
        else:
            st.info("Player of Match column not present.")




# -------------------- Top Players --------------------
elif page == "Top Players":
    st.header("🏆 Top Players (Overall)")

    def has(col):
        return col in df.columns

    # -------------------- Top Run Scorers --------------------
    runs_col = 'runs_batter' if has('runs_batter') else ('batter_runs' if has('batter_runs') else None)
    if runs_col and has('batter'):
        top_batters = (
            df.groupby('batter')[runs_col]
            .sum()
            .reset_index()
            .sort_values(runs_col, ascending=False)
            .head(30)
        )
        st.subheader("🏏 Top Run Scorers")
        st.dataframe(top_batters)
        st.plotly_chart(px.bar(top_batters.head(15), x=runs_col, y='batter', orientation='h',
                               title="Top 15 Run Scorers",
                               color=runs_col, color_continuous_scale='blues'))
    else:
        st.info("Batter run columns not available.")

    # -------------------- Top Wicket Takers --------------------
    st.subheader("🎯 Top Wicket Takers")
    if has('bowler') and has('bowler_wicket'):
        top_bowlers = (
            df.groupby('bowler')['bowler_wicket']
            .sum()
            .reset_index()
            .sort_values('bowler_wicket', ascending=False)
            .head(30)
        )
        st.dataframe(top_bowlers)
        st.plotly_chart(px.bar(top_bowlers.head(15), x='bowler_wicket', y='bowler', orientation='h',
                               title="Top 15 Wicket Takers",
                               color='bowler_wicket', color_continuous_scale='oranges'))
    else:
        st.info("Bowler wicket data not available.")

    # -------------------- Most Sixes --------------------
    st.subheader("💥 Most Sixes Hit")
    if runs_col and has('batter'):
        sixes_df = df[df[runs_col] == 6]
        top_sixes = (
            sixes_df.groupby('batter')[runs_col]
            .count()
            .reset_index()
            .rename(columns={runs_col: 'Sixes'})
            .sort_values('Sixes', ascending=False)
            .head(30)
        )
        st.dataframe(top_sixes)
        st.plotly_chart(px.bar(top_sixes.head(15), x='Sixes', y='batter', orientation='h',
                               title="Top 15 Six Hitters",
                               color='Sixes', color_continuous_scale='reds'))
    else:
        st.info("Batter sixes data not available.")

    # -------------------- Most Fours --------------------
    st.subheader("🔥 Most Fours Hit")
    if runs_col and has('batter'):
        fours_df = df[df[runs_col] == 4]
        top_fours = (
            fours_df.groupby('batter')[runs_col]
            .count()
            .reset_index()
            .rename(columns={runs_col: 'Fours'})
            .sort_values('Fours', ascending=False)
            .head(30)
        )
        st.dataframe(top_fours)
        st.plotly_chart(px.bar(top_fours.head(15), x='Fours', y='batter', orientation='h',
                               title="Top 15 Four Hitters",
                               color='Fours', color_continuous_scale='greens'))
    else:
        st.info("Batter fours data not available.")



# -------------------- Player Detail --------------------
elif page == "Player Detail":
    st.markdown("<h2 style='text-align:center; color:#2e7d32;'>🏏 Player Detail Analytics</h2>", unsafe_allow_html=True)
    st.markdown("<hr>", unsafe_allow_html=True)

    def has(col):
        return col in df.columns

    # Select Role
    role = st.selectbox("Select Role", ["Batter", "Bowler"])

    # ================= BATTER DETAILS =================
    if role == "Batter":
        if not has('batter'):
            st.warning("⚠️ No 'batter' column found in dataset.")
        else:
            p = st.selectbox("Select Batter", sorted(df['batter'].dropna().unique()))
            p_df = df[df['batter'] == p]

            # Ensure numeric
            for col in ['runs_batter', 'balls_faced']:
                if has(col):
                    p_df[col] = pd.to_numeric(p_df[col], errors='coerce').fillna(0)

            runs_col = 'runs_batter'
            balls_col = 'balls_faced'

            total_runs = p_df[runs_col].sum()
            total_balls = p_df[balls_col].sum()
            total_4s = (p_df[runs_col] == 4).sum()
            total_6s = (p_df[runs_col] == 6).sum()
            dismissals = p_df[p_df['player_out'] == p].shape[0] if has('player_out') else 0
            innings = p_df['match_id'].nunique() if has('match_id') else 0
            ducks = (p_df.groupby('match_id')[runs_col].sum() == 0).sum() if has('match_id') else 0

            sr = round((total_runs / total_balls * 100), 2) if total_balls > 0 else 0
            avg = round(total_runs / dismissals, 2) if dismissals > 0 else 0

            st.markdown(f"<h3 style='color:#1b5e20;'>📊 Batting Summary: {p}</h3>", unsafe_allow_html=True)

            # Styled Metrics
            c1, c2, c3, c4 = st.columns(4)
            with c1: st.metric("🏏 Total Runs", f"{int(total_runs)}")
            with c2: st.metric("⚡ Strike Rate", f"{sr}")
            with c3: st.metric("🎯 Average", f"{avg}")
            with c4: st.metric("🦆 Ducks", f"{ducks}")

            c5, c6, c7, c8 = st.columns(4)
            with c5: st.metric("🔥 Fours", f"{int(total_4s)}")
            with c6: st.metric("💥 Sixes", f"{int(total_6s)}")
            with c7: st.metric("⏱️ Balls Faced", f"{int(total_balls)}")
            with c8: st.metric("📘 Innings Played", f"{int(innings)}")

            # 💥 Runs vs Bowler chart
            if has('bowler'):
                runs_vs_bowler = p_df.groupby('bowler')[runs_col].sum().reset_index().sort_values(runs_col, ascending=False).head(10)
                if not runs_vs_bowler.empty:
                    st.markdown(f"<h4 style='color:#2e7d32;'>💥 Top Bowlers {p} Scored Most Against</h4>", unsafe_allow_html=True)
                    fig = px.bar(
                        runs_vs_bowler,
                        x='bowler',
                        y=runs_col,
                        text=runs_col,
                        title=f"{p}'s Top Bowlers Faced",
                        color_discrete_sequence=['#66bb6a']
                    )
                    fig.update_traces(textposition='outside')
                    fig.update_layout(xaxis_title="", yaxis_title="Runs", title_x=0.3, plot_bgcolor='rgba(0,0,0,0)')
                    st.plotly_chart(fig, use_container_width=True)

    # ================= BOWLER DETAILS =================
    else:
        if not has('bowler'):
            st.warning("⚠️ No 'bowler' column found in dataset.")
        else:
            p = st.selectbox("Select Bowler", sorted(df['bowler'].dropna().unique()))
            p_df = df[df['bowler'] == p]

            for col in ['bowler_wicket', 'runs_total', 'runs_extras']:
                if has(col):
                    p_df[col] = pd.to_numeric(p_df[col], errors='coerce').fillna(0)

            total_wk = int(p_df['bowler_wicket'].sum())
            total_runs = int(p_df['runs_total'].sum())
            total_extras = int(p_df['runs_extras'].sum())
            legal_deliveries = p_df[p_df['valid_ball'] == 1].shape[0] if has('valid_ball') else len(p_df)
            overs = legal_deliveries // 6 + (legal_deliveries % 6) / 10.0
            economy = round(total_runs / (legal_deliveries / 6), 2) if legal_deliveries > 0 else 0
            innings = p_df['match_id'].nunique() if has('match_id') else 0

            st.markdown(f"<h3 style='color:#1b5e20;'>🎯 Bowling Summary: {p}</h3>", unsafe_allow_html=True)

            c1, c2, c3, c4 = st.columns(4)
            with c1: st.metric("🎳 Wickets", total_wk)
            with c2: st.metric("📏 Overs", round(overs, 1))
            with c3: st.metric("💰 Economy", economy)
            with c4: st.metric("📘 Innings", innings)

            c5, c6, c7 = st.columns(3)
            with c5: st.metric("⚡ Deliveries", len(p_df))
            with c6: st.metric("✅ Legal Deliveries", int(legal_deliveries))
            with c7: st.metric("💥 Extras", total_extras)

            # 🥧 Extras Pie
            if has('extra_type'):
                extras_breakdown = p_df['extra_type'].value_counts().reset_index()
                extras_breakdown.columns = ['Extra Type', 'Count']
                if not extras_breakdown.empty:
                    st.markdown("<h4 style='color:#2e7d32;'>🥧 Extras Breakdown</h4>", unsafe_allow_html=True)
                    fig = px.pie(extras_breakdown, values='Count', names='Extra Type', hole=0.4,
                                 color_discrete_sequence=px.colors.qualitative.Safe)
                    st.plotly_chart(fig, use_container_width=True)


# -------------------- Venues --------------------
elif page == "Venues":
    st.header("Venue Analytics")
    if not has('venue'):
        st.info("No venue column.")
    else:
        venue = st.selectbox("Select Venue", options=["All"] + venues_all)
        if venue!="All":
            vdf = df[df['venue'].astype(str)==venue]
            st.write("Rows:", vdf.shape[0])
            if has('match_won_by'):
                winners = vdf.groupby('match_id')['match_won_by'].first().value_counts().reset_index()
                winners.columns = ['Team','Wins']
                st.dataframe(winners.head(10))
                st.plotly_chart(px.bar(winners.head(10), x='Team', y='Wins', title=f"Teams successful at {venue}"), use_container_width=True)
            if has('runs_total'):
                st.metric("Avg runs/ball at venue", round(vdf['runs_total'].mean(),3))




# -------------------- Head to Head --------------------
elif page == "Head to Head":
    st.header("🤝 Team vs Team — Head-to-Head Analysis")

    # ---------------------------- 🏏 Full + Short Team Names ----------------------------
    team_full_short = {
        "Gujarat Titans": "GT",
        "Kochi Tuskers Kerala": "KTK",
        "Kolkata Knight Riders": "KKR",
        "Lucknow Super Giants": "LSG",
        "Mumbai Indians": "MI",
        "Punjab Kings": "PBKS",
        "Rajasthan Royals": "RR",
        "Rising Pune Supergiants": "RPS",
        "Royal Challengers Bengaluru": "RCB",
        "Sunrisers Hyderabad": "SRH",
        "Chennai Super Kings": "CSK",
        "Delhi Capitals": "DC",
        "Deccan Chargers": "DCG"
    }

    # Apply team name replacements if available
    team_replacements = {
        'Delhi Daredevils': 'Delhi Capitals',
        'Kings XI Punjab': 'Punjab Kings',
        'Deccan Chargers': 'Sunrisers Hyderabad',
        'Rising Pune Supergiant': 'Rising Pune Supergiants',
        'Pune Warriors': 'Rising Pune Supergiants',
        'Gujarat Lions': 'Gujarat Titans',
        'Royal Challengers Bangalore': 'Royal Challengers Bengaluru',
        'RCB': 'Royal Challengers Bengaluru',
        'MI': 'Mumbai Indians',
        'CSK': 'Chennai Super Kings',
        'KKR': 'Kolkata Knight Riders',
        'SRH': 'Sunrisers Hyderabad',
        'PBKS': 'Punjab Kings',
        'GT': 'Gujarat Titans',
        'LSG': 'Lucknow Super Giants',
        'KTK': 'Kochi Tuskers Kerala',
        'RPS': 'Rising Pune Supergiants'
    }

    # Replace names in DataFrame
    for col in ['batting_team', 'bowling_team', 'match_won_by']:
        if col in df.columns:
            df[col] = df[col].astype(str).replace(team_replacements)

    # ---------------------------- Dropdown Teams ----------------------------
    if not teams_all:
        st.info("No teams detected in dataset.")
    else:
        # Standardize team list and show short names in dropdown
        teams_all = sorted(set([team_replacements.get(t, t) for t in teams_all]))
        team_display = [f"{t} ({team_full_short.get(t, '')})" if t in team_full_short else t for t in teams_all]
        team_map = {f"{t} ({team_full_short.get(t, '')})": t for t in teams_all}

        col1, col2 = st.columns(2)
        with col1:
            team1_display = st.selectbox("Select Team 1", team_display, index=0)
        with col2:
            team2_display = st.selectbox("Select Team 2", [t for t in team_display if t != team1_display], index=0)

        team1 = team_map[team1_display]
        team2 = team_map[team2_display]

        st.markdown(f"### 🏏 {team1_display} vs {team2_display}")

        # ---------------------------- Filter matches involving both teams ----------------------------
        if {'batting_team', 'bowling_team'}.issubset(df.columns):
            h2h_df = df[
                ((df['batting_team'] == team1) & (df['bowling_team'] == team2)) |
                ((df['batting_team'] == team2) & (df['bowling_team'] == team1))
            ]
        else:
            h2h_df = pd.DataFrame()

        if h2h_df.empty:
            st.warning("No matches found between these teams in dataset.")
        else:
            match_df = match_level_agg(h2h_df)
            total_matches = match_df.shape[0]
            wins_team1 = match_df[match_df['match_won_by'] == team1].shape[0]
            wins_team2 = match_df[match_df['match_won_by'] == team2].shape[0]
            ties = total_matches - wins_team1 - wins_team2

            colA, colB, colC, colD = st.columns(4)
            colA.metric("Total Matches", total_matches)
            colB.metric(f"Wins — {team1_display}", wins_team1)
            colC.metric(f"Wins — {team2_display}", wins_team2)
            colD.metric("Tied/No Result", ties)

            # ---------------------------- Bar Chart ----------------------------
            win_data = pd.DataFrame({
                'Team': [team1_display, team2_display, 'Tie/NR'],
                'Wins': [wins_team1, wins_team2, ties]
            })
            fig = px.bar(win_data, x='Team', y='Wins', color='Team',
                         title=f"{team1_display} vs {team2_display} — Head to Head Record",
                         text='Wins')
            st.plotly_chart(fig, use_container_width=True)

            # ---------------------------- Season-wise trend ----------------------------
            if 'season' in match_df.columns:
                seasonwise = match_df.groupby(['season', 'match_won_by']).size().reset_index(name='Wins')
                seasonwise = seasonwise[seasonwise['match_won_by'].isin([team1, team2])]
                seasonwise['match_won_by'] = seasonwise['match_won_by'].map({
                    team1: team1_display,
                    team2: team2_display
                })
                fig2 = px.bar(seasonwise, x='season', y='Wins', color='match_won_by',
                              barmode='group', title=f"Season-wise Head to Head: {team1_display} vs {team2_display}")
                st.plotly_chart(fig2, use_container_width=True)

            # ---------------------------- Venue-wise trend ----------------------------
            if 'venue' in match_df.columns:
                venuewise = match_df.groupby(['venue', 'match_won_by']).size().reset_index(name='Wins')
                venuewise = venuewise[venuewise['match_won_by'].isin([team1, team2])]
                top_venues = venuewise['venue'].value_counts().index[:10]
                venuewise = venuewise[venuewise['venue'].isin(top_venues)]
                venuewise['match_won_by'] = venuewise['match_won_by'].map({
                    team1: team1_display,
                    team2: team2_display
                })
                fig3 = px.bar(venuewise, x='venue', y='Wins', color='match_won_by',
                              barmode='group', title=f"Top Venues — {team1_display} vs {team2_display}")
                st.plotly_chart(fig3, use_container_width=True)

            # ---------------------------- Player of Match leaders ----------------------------
            if 'player_of_match' in match_df.columns:
                pom = match_df['player_of_match'].value_counts().reset_index()
                pom.columns = ['Player', 'Awards']
                st.subheader("🌟 Top Player of the Match Winners in H2H")
                st.dataframe(pom.head(10))
                st.plotly_chart(px.bar(pom.head(10), x='Awards', y='Player', orientation='h',
                                       title=f"Top PoM — {team1_display} vs {team2_display}"), use_container_width=True)



# -------------------- Prediction Section --------------------
if page == "Prediction":
    st.header("🤖 Match Outcome Prediction")
    st.write("Predict match result based on historical data, toss outcome, and team performance.")

    # ✅ Official IPL Teams (Full + Short Names)
    ipl_teams = [
        "Mumbai Indians (MI)",
        "Chennai Super Kings (CSK)",
        "Kolkata Knight Riders (KKR)",
        "Sunrisers Hyderabad (SRH)",
        "Rajasthan Royals (RR)",
        "Royal Challengers Bengaluru (RCB)",
        "Punjab Kings (PBKS)",
        "Delhi Capitals (DC)",
        "Lucknow Super Giants (LSG)",
        "Gujarat Titans (GT)",
        "Rising Pune Supergiants (RPS)",
        "Kochi Tuskers Kerala (KTK)"
    ]

    # --- User Inputs ---
    st.subheader("🎯 Input Match Details")

    col1, col2 = st.columns(2)

    with col1:
        batting_team = st.selectbox("Team 1 (Batting First)", ipl_teams, index=0)
        bowling_team = st.selectbox("Team 2 (Bowling First)", [t for t in ipl_teams if t != batting_team], index=1)
        venue = st.selectbox("Venue", sorted(df['venue'].dropna().unique()))

    with col2:
        toss_winner = st.selectbox("Toss Winner", [batting_team, bowling_team])
        toss_decision = st.selectbox("Toss Decision", ["bat", "field"])

        # ✅ Season cleanup — only keep 2008–2024
        if 'season' in df.columns:
            df['season'] = df['season'].astype(str).str.extract(r'(\d{4})')[0]
            df['season'] = pd.to_numeric(df['season'], errors='coerce')
        elif 'year' in df.columns:
            df['year'] = df['year'].astype(str).str.extract(r'(\d{4})')[0]
            df['year'] = pd.to_numeric(df['year'], errors='coerce')
            df.rename(columns={'year': 'season'}, inplace=True)
        else:
            df['season'] = np.nan

        # ✅ Restrict to 2008–2024 (remove 2007 completely)
        df = df[(df['season'] >= 2008) & (df['season'] <= 2024)]

        available_seasons = sorted(df['season'].dropna().unique().astype(int).tolist())
        # If some years missing, ensure all from 2008–2024 appear
        for y in range(2008, 2025):
            if y not in available_seasons:
                available_seasons.append(y)
        available_seasons = sorted(set(available_seasons))

        # Default = 2024
        season_value = st.selectbox("Season", available_seasons, index=available_seasons.index(2024))

    # --- Display chosen values ---
    st.write("**Selected Inputs:**")
    st.write(f"- Team 1: {batting_team}")
    st.write(f"- Team 2: {bowling_team}")
    st.write(f"- Venue: {venue}")
    st.write(f"- Toss Winner: {toss_winner}")
    st.write(f"- Toss Decision: {toss_decision}")
    st.write(f"- Season: {season_value}")

    # --- Clean team names (remove short codes) ---
    def clean_team_name(name):
        return name.split(" (")[0].strip()

    team1_clean = clean_team_name(batting_team)
    team2_clean = clean_team_name(bowling_team)

    # --- Filter data ---
    subset = df[
        ((df['batting_team'] == team1_clean) & (df['bowling_team'] == team2_clean)) |
        ((df['batting_team'] == team2_clean) & (df['bowling_team'] == team1_clean))
    ]
    subset = subset[subset['season'] == season_value]

    # --- Toss Info ---
    st.info(f"🎯 Toss Winner: **{toss_winner}**, Decision: **{toss_decision.capitalize()}**")

    # --- Predicted Match Winner ---
    st.subheader("🏆 Predicted Match Winner (Historical Trend)")
    if not subset.empty and 'match_won_by' in subset.columns:
        winner_counts = subset['match_won_by'].value_counts()
        predicted_winner = winner_counts.index[0]
        win_prob = round((winner_counts.iloc[0] / winner_counts.sum()) * 100, 2)
        st.success(f"🏆 Predicted Winner: **{predicted_winner}** ({win_prob}% chance)")
    else:
        st.warning("Not enough historical data for this combination to predict outcome.")

    # --- Head-to-Head Chart ---
    if not subset.empty:
        st.subheader("📊 Historical Head-to-Head Results")
        h2h_df = subset['match_won_by'].value_counts().reset_index()
        h2h_df.columns = ['Team', 'Wins']
        fig = px.bar(
            h2h_df, x='Team', y='Wins', color='Team',
            title=f"{batting_team} vs {bowling_team} - Historical Results",
            labels={'Team': 'Team', 'Wins': 'Number of Wins'}
        )
        st.plotly_chart(fig, use_container_width=True)

    # --- Toss Winner Comparison ---
    if not subset.empty and 'toss_winner' in subset.columns:
        st.subheader("🎯 Toss Winner Comparison")
        toss_df = subset['toss_winner'].value_counts().reset_index()
        toss_df.columns = ['Team', 'Toss Wins']
        fig2 = px.bar(
            toss_df, x='Team', y='Toss Wins', color='Team',
            title=f"{batting_team} vs {bowling_team} - Toss Wins",
            labels={'Team': 'Team', 'Toss Wins': 'Number of Toss Wins'}
        )
        st.plotly_chart(fig2, use_container_width=True)

    # --- Toss Decision Impact ---
    if not subset.empty and {'toss_decision', 'match_won_by', 'toss_winner'}.issubset(subset.columns):
        st.subheader("⚡ Toss Decision Impact on Match Results")

        toss_decision_df = subset.dropna(subset=['toss_winner', 'toss_decision', 'match_won_by']).copy()
        toss_decision_df['TossWin_MatchWin'] = toss_decision_df.apply(
            lambda x: 'Won Match After Toss' if x['toss_winner'] == x['match_won_by'] else 'Lost Match After Toss',
            axis=1
        )

        decision_summary = toss_decision_df.groupby(['toss_decision', 'TossWin_MatchWin']).size().reset_index(name='Count')

        fig3 = px.bar(
            decision_summary,
            x='toss_decision',
            y='Count',
            color='TossWin_MatchWin',
            barmode='group',
            title="Impact of Toss Decision on Match Result",
            labels={'toss_decision': 'Toss Decision', 'Count': 'Number of Matches'}
        )
        st.plotly_chart(fig3, use_container_width=True)
